/* nothing , only the stub */
/* gohigh */

#include <errno.h>

int sys_select()
{
	return -ENOSYS;
}

